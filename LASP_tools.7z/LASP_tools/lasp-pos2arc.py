#! /home/lammps/anaconda2/bin/python2.7

__author__ = 'zpliu learn from hsd Arcread.py'

import time
import cmath as m
import os
import numpy as np
import random
import sys
#import template as Tp
import string
sys.path.append('/home/lammps/software-pack/LASP_Example/')
#from XYZCoord import *   #  XYZCoord, BadStr, FooError, ParaWrap_JudgeShape, ParaWrap_Shortestbond
from multiprocessing import Pool
#import PeriodicTable as PT 
#from XYZCoordSet import CoordSet
import LASP_PythonLib 
from LASP_PythonLib.structure_new import Str
from LASP_PythonLib.allstr_new import allstr as allstr_new



if __name__ == "__main__":
    if len( sys.argv ) < 2 :
        print( "Please use following syntax :" )
        print( " pos2arc format " )
        print( " format : required argument, being arc2pos / pos2arc " )
        import sys
        sys.exit( )

    AllStr= allstr_new()

    if sys.argv[1] == "pos2arc":
# POSCAR to arc
        AllStr.BuildCoordSet_fromPOSCAR()
        AllStr.Gen_arc(range(len(AllStr)),'outstr.arc',2)
    if sys.argv[1] == "arc2pos":
#  arc to POSCAR
        AllStr.arcinit([0,0],'all.arc')  
        for i in range(len(AllStr)): AllStr.GenPOSCAR_VASP(i)

