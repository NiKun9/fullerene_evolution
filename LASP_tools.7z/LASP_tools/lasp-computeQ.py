#! /home/lammps/anaconda2/bin/python2.7

__author__ = 'zpliu learn from hsd Arcread.py'

# modifed from screenminimum -- only for compute Q
import time
import cmath as m
import os
import numpy as np
import random
import sys
#import template as Tp
import string
sys.path.append('/home/lammps/software-pack/LASP_Example/')
from multiprocessing import Pool
import LASP_PythonLib
from LASP_PythonLib.structure_new import Str, ParaWrap_SteinhartQ_cal ,ParaWrap_JudgeShape 
from LASP_PythonLib.allstr_new import BadStr 
from LASP_PythonLib.allstr_new import allstr as allstr_new


if __name__ == "__main__":
    AllStr= allstr_new()
    AllStr.arcinit([0,0],'all.arc')    # structure file name of all.arc
    print 'All Str:',len(AllStr)
    Ncore = 32

    print ' python job started at', time.strftime('%d/%m/%Y %H:%M:%S')

# parallel version
    Ncore=32
#   stage 1
  
    f= ParaWrap_SteinhartQ_cal
    results = AllStr.ParaRun(f,Ncore)
    record=0
    b=[]
    for x in results:
        for y1,y2,y3,y4,y5,y6 in x.get():
            record +=1
            AllStr[record-1].Q.append(y1)
            AllStr[record-1].Q.append(y2)
            AllStr[record-1].Q.append(y3)
            AllStr[record-1].Q.append(y4)
            AllStr[record-1].Q.append(y5)
            AllStr[record-1].Q.append(y6)


#   if len(AllStr) >0:
#       AllStr.Gen_arc(range(len(AllStr)))


    print "Summary of Stein-Q value Minimum"
    print "                     Q2          Q4          Q6   "
    for i in range(len(AllStr)):
        print "%5d   %8.4f  %8.4f  %8.4f  %8.4f  "%(i,AllStr[i].Energy,float(AllStr[i].Q[0]),
           float(AllStr[i].Q[1]),float(AllStr[i].Q[2]))

    print 'Finish ---------------------------------------------'


    print "Summary of Distance-weighted Stein-Q value Minimum"
    print "                     Q2          Q4          Q6   "
    for i in range(len(AllStr)):
        print "%5d   %8.4f  %8.4f  %8.4f  %8.4f  "%(i,AllStr[i].Energy,float(AllStr[i].Q[3]),
           float(AllStr[i].Q[4]),float(AllStr[i].Q[5]))

    print 'Finish ---------------------------------------------'
