#!/usr/bin/env python
#coding:utf-8
import numpy as np
import os
from math import pi, acos
import re
import pandas as pd



Eledict = {'H': 1, 'He': 2, 'Li': 3, 'Be': 4, 'B': 5, 'C': 6, 'N': 7, 'O': 8, 'F': 9, 'Ne': 10, 'Na': 11, 'Mg': 12,
		   'Al': 13, 'Si': 14, 'P': 15, 'S': 16, 'Cl': 17, 'Ar': 18, 'K': 19, 'Ca': 20, 'Sc': 21, 'Ti': 22, 'V': 23,
		   'Cr': 24, 'Mn': 25, 'Fe': 26, 'Co': 27, 'Ni': 28, 'Cu': 29, 'Zn': 30, 'Ga': 31, 'Ge': 32, 'As': 33,
		   'Se': 34, 'Br': 35, 'Kr': 36, 'Rb': 37, 'Sr': 38, 'Y': 39, 'Zr': 40, 'Nb': 41, 'Mo': 42, 'Tc': 43,
		   'Ru': 44, 'Rh': 45, 'Pd': 46, 'Ag': 47, 'Cd': 48, 'In': 49, 'Sn': 50, 'Sb': 51, 'Te': 52, 'I': 53,
		   'Xe': 54, 'Cs': 55, 'Ba': 56, 'La': 57, 'Ce': 58, 'Pr': 59, 'Nd': 60, 'Pm': 61, 'Sm': 62, 'Eu': 63,
		   'Gd': 64, 'Tb': 65, 'Dy': 66, 'Ho': 67, 'Er': 68, 'Tm': 69, 'Yb': 70, 'Lu': 71, 'Hf': 72, 'Ta': 73,
		   'W': 74, 'Re': 75, 'Os': 76, 'Ir': 77, 'Pt': 78, 'Au': 79, 'Hg': 80, 'Tl': 81, 'Pb': 82, 'Bi': 83,
		   'Th': 90, 'Pa': 91, 'U': 92}


class readOUTCAR():
	def __init__(self,filename='OUTCAR'):
		self.INCAR = {
					'NKPTS' 	: 	0,		'NBANDS'	 :	0,
					'NIONS'		 :	0,	'ions per type'  :	[],
					'ISPIN'		 :	0,		'ENCUT'		 :	0,
					'EDIFF'		 :	0,		'LREAL'		 :	'F',
					'NELM'		 :	0,		'EDIFFG'	 :	0,
					'NSW'		 :	0,		'IBRION'	 :	0,
					'ISIF'		 :	0,		'ISYM'		 :	0,
					'POTIM'		 :	0,		'PSTRESS'	 :	0,
					'NELECT'	 :	0,		'HFSCREEN'	 :	0,
					'ISMEAR'	 :	0,		'SIGMA'		 :	0,
					'ATOMTYPE'	 :	[],		'LORBIT'	 :	0,
					'LDAUTYPE'	 :	0,		'LDAUL'		 :	'',
					'LDAUU'		 :	'',		'LDAUJ'		 :	'',
					'LDIPOL'	 :	'F',	'IDIPOL'	 :	0,
					'GGA'		 : 'PE',	'LHFCALC' 	 :	'F',
					'LDAU'		 :	'F',	'atominfo'	  :	[],
					}
		self.structure = {
					'lattice'		:	[],		'position'		:	[],
					'stress'		:	[],		'force'			:	[],
					'volume'		:	[],		'convergence'	:	{},
					'eigenvalue'	:	[],
					}
		self.energy  = {
					'free energy':	[],	'energy without entropy':	[],	'energy':	[]
					}
		self.electronics = {
					'fermi'		:	[], 	'bandgap':	[],
					'HOMO'		:	[],		'LUMO'	:	[],
					'magnetic'	:	{},
					}
		with open(filename,'r') as f:	lines = f.readlines()
		for i,v in enumerate(lines):
			if 'POTCAR:' in v:
				aa = v.split()[2]
				if aa not in self.INCAR['ATOMTYPE']:
					self.INCAR['ATOMTYPE'].append(aa)
			elif 'NKPTS' in v:
				aa = v.split();				self.INCAR['NKPTS'] = int(aa[3]);	self.INCAR['NBANDS'] = int(aa[-1])
				aa = lines[i+1].split();	self.INCAR['NIONS'] = int(aa[-1])
				aa = lines[i+8].split();	self.INCAR['ions per type'] = [int(j) for j in aa[4:]]
			elif 'ISPIN' in v:
				self.INCAR['ISPIN'] = int(v.split()[2])
			elif 'ENCUT ' in v:
				self.INCAR['ENCUT'] =  float(v.split()[2])
				self.INCAR['NELM'] = int(lines[i+3].split()[2].split(';')[0])
				self.INCAR['EDIFF'] = float(lines[i+4].split()[2])
				self.INCAR['LREAL'] = lines[i+5].split()[2]
			elif 'EDIFFG' in v:
				self.INCAR['EDIFFG'] = float(v.split()[2])
				aa = lines[i+1].split()[2]
				if aa == '******':
					self.INCAR['NSW'] = 10000
				else:
					self.INCAR['NSW'] = int(aa)
				self.INCAR['IBRION'] = int(lines[i+3].split()[2])
				self.INCAR['ISIF'] = int(lines[i+5].split()[2])
				self.INCAR['ISYM'] = int(lines[i+7].split()[2])
			elif 'POTIM' in v:
				self.INCAR['POTIM'] = float(v.split()[2])
				self.INCAR['PSTRESS'] = float(lines[i+7].split()[1])
			elif 'NELECT' in v:
				self.INCAR['NELECT'] = float(v.split()[2])
			elif 'ISMEAR' in v:
				aa = v.split();		self.INCAR['ISMEAR'] = int(aa[2].split(';')[0]);	self.INCAR['SIGMA'] = float(aa[5])
			elif 'LORBIT' in v:
				self.INCAR['LORBIT'] = int(v.split()[2])
			elif 'LDIPOL' in v:
				self.INCAR['LDIPOL'] = v.split()[2]
				self.INCAR['IDIPOL'] = int(lines[i+1].split()[2])
			elif 'LDAUTYPE' in v:
				self.INCAR['LDAU'] = 'T'
				self.INCAR['LDAUTYPE'] = int(v.split()[-1])
				self.INCAR['LDAUL'] = ' '.join(lines[i + 1].split()[7:])
				self.INCAR['LDAUU'] = ' '.join(lines[i + 2].split()[7:])
				self.INCAR['LDAUJ'] = ' '.join(lines[i + 3].split()[7:])
			elif 'GGA' in v:
				self.INCAR['GGA'] = v.split()[2]
			elif 'LHFCALC' in v:
				self.INCAR['LHFCALC'] = v.split()[2]
			elif 'HFSCREEN' in v:
				self.INCAR['HFSCREEN'] = float(v.split()[1])
			elif 'FORCE on cell' in v:
				aa = [float(j) for j in lines[i + 13].split()[1:]]
				self.structure['stress'].append(np.array(aa))
			elif 'VOLUME and BASIS-vectors' in v:
				self.structure['volume'].append(float(lines[i + 3].split()[4]))
				aa = np.loadtxt(lines[i + 5 : i + 8])[:,:3]
				aa = latt2abc(aa)
				self.structure['lattice'].append(aa)
			elif 'POSITION' in v:
				atoms = sum(self.INCAR['ions per type'])
				aa = np.loadtxt(lines[i + 2 : i + 2 + atoms])
				self.structure['position'].append(aa[:,:3])
				self.structure['force'].append(aa[:,3:])
				self.structure['eigenvalue'].append(eigenvalue(aa[:,:3]))
				aa = lines[i + 10 + atoms ]
				if 'FREE ENERGIE OF THE ION-ELECTRON SYSTEM' in aa:
					self.energy['free energy'].append(float(lines[i + 12 + atoms].split()[-2]))
					aa = lines[i + 14 + atoms].split()
					self.energy['energy without entropy'].append(float(aa[3]))
					self.energy['energy'].append(float(aa[-1]))
				else:
					self.INCAR = []
					self.structure = []
					self.energy = []
					break
			elif 'Iteration' in v:
				mm = re.findall(r'\d+',v)
				self.structure['convergence'][mm[0]] = int(mm[1])
			elif 'number of electron' in v:
				try:
					self.electronics['magnetic'][mm[0]] = float(v.split()[-1])
				except:
					pass
			elif 'E-fermi' in v:
				self.electronics['fermi'].append(float(v.split()[2]))
				self.electronics['HOMO'].append([])
				self.electronics['LUMO'].append([])
			elif 'band energies' in v:
				aa = np.loadtxt(lines[i + 1 : i + 1 + self.INCAR['NBANDS']])
				for j in range(aa.shape[0]):
					if aa[j,1] > self.electronics['fermi'][-1]:
						self.electronics['HOMO'][-1].append(aa[j-1, 1 ])
						self.electronics['LUMO'][-1].append(aa[j, 1 ])
						break
		self.INCAR['atominfo']  = [[self.INCAR['ATOMTYPE'][i],Eledict[self.INCAR['ATOMTYPE'][i]] ,self.INCAR['ions per type'][i]] \
								   for i in range(len(self.INCAR['ATOMTYPE']))]
		self.INCAR['atominfo'] = pd.DataFrame(self.INCAR['atominfo'], columns= ['atomtype','atomorder','atomnumber']).sort_values(by='atomorder',ascending=False)
		self.structure['convergence'] = list(self.structure['convergence'].values())
		self.electronics['magnetic'] = list(self.electronics['magnetic'].values())
		for i in range(len(self.structure['stress'])):
			self.structure['stress'][i] = - self.structure['stress'][i] / self.structure['volume'][i]
		for i in range(len(self.electronics['fermi'])):
			self.electronics['bandgap'].append(min(self.electronics['LUMO'][i]) - max(self.electronics['HOMO'][i]))

def latt2abc(latt):
	latt = np.mat(latt)
	abc = np.zeros((6))
	abc[0] = np.linalg.norm(latt[0])
	abc[1] = np.linalg.norm(latt[1])
	abc[2] = np.linalg.norm(latt[2])
	ua = latt[0]/abc[0]
	ub = latt[1]/abc[1]
	uc = latt[2]/abc[2]
	abc[3] = 180.0/pi*acos(ub*uc.T)
	abc[4] = 180.0/pi*acos(ua*uc.T)
	abc[5] = 180.0/pi*acos(ua*ub.T)
	return abc

def eigenvalue(positions):
	atomnumber = positions.shape[0]
	distancematrix = np.zeros((atomnumber, atomnumber))
	for i in range(atomnumber):
		for j in range(atomnumber):
			distancematrix[i,j] = np.linalg.norm(positions[i,:] - positions[j,:])
			distancematrix[j,i] = distancematrix[i,j]
	eigenvalue = np.linalg.eigvals(distancematrix)
	return sum(abs(eigenvalue))

def eigenvalueError(_data,error = 0.01):
	_data = pd.Series(_data)
	label = [0]
	while True:
		_data = _data[abs(_data - _data[label[-1]]) > error]
		if len(_data.index) == 0:
			break
		else:
			label.append(_data.index[0])
	return label
def printallele(outcar):
	ISPIN = outcar.INCAR['ISPIN']
	NKPTS = outcar.INCAR['NKPTS']
	fermi = outcar.electronics['fermi']
	HOMO = outcar.electronics['HOMO']
	LUMO = outcar.electronics['LUMO']
	bandgap = outcar.electronics['bandgap']
	magnetic = outcar.electronics['magnetic']
	f = open('allele.txt','w')	
	if ISPIN == 2:
		for i in range(len(HOMO)):
			a = max(HOMO[i][:NKPTS])
			b = min(LUMO[i][:NKPTS])
			c = max(HOMO[i][NKPTS:])
			d = min(LUMO[i][NKPTS:])
			print ('ISPIN  2',file = f)
			print ('magnetic %.2f' %magnetic[i],file = f)
			print ('HOMO  %.3f  %.3f  %.3f' %(max(a,c),a,c),file = f)
			print ('LUMO  %.3f  %.3f  %.3f' %(max(b,d),b,d),file = f)
			print ('band gap  %.3f  %.3f  %.3f' %(min(b-a,d-c),b-a,d-c),file = f)
			print ('',file = f)
	elif ISPIN == 1:
		for i in range(len(HOMO)):
			print ('ISPIN  1',file = f)
			print ('HOMO  %.3f ' %(HOMO[i]),file = f)
			print ('LUMO  %.3f ' %(LUMO[i]),file = f)
			print ('band gap  %.3f ' %(bandgap[i]),file = f)

if __name__ == '__main__':
	a = readOUTCAR('OUTCAR')
	printallele(a)
